<?php
/**
 * Created by PhpStorm.
 * User: Bibesh
 * Date: 8/11/17
 * Time: 9:39 AM
 */

$host = "localhost";
$uname = "root";
$pwd = "";
$table = "tokens";
$db = "firebase";

$con = mysqli_connect($host, $uname, $pwd, $db) or die(mysqli_error($con));