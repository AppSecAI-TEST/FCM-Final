<?php
/**
 * Created by PhpStorm.
 * User: Bibesh
 * Date: 8/10/17
 * Time: 4:42 PM
 */
header('location:message.html');
