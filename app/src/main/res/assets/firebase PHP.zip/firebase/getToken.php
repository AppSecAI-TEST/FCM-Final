<?php
/**
 * Created by PhpStorm.
 * User: Bibesh
 * Date: 8/11/17
 * Time: 9:39 AM
 */

require('connection.php');
echo $token = $_POST['token'];
$sendQuery = "INSERT INTO $table(token) VALUES('$token')";
$response = mysqli_query($con, $sendQuery) or die(mysqli_error($con));

