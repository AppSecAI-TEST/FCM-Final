<?php
/**
 * Created by PhpStorm.
 * User: Bibesh
 * Date: 8/11/17
 * Time: 9:35 AM
 */
include('connection.php');

$subject = $_GET['subject'];
$myMessage = $_GET['message'];

function send_notification($tokens, $message)
{
    $url = 'https://fcm.googleapis.com/fcm/send';
    $fields = array(
        'registration_ids' => $tokens,
        'data' => $message,
        'notification' => $message
    );
    $header = array('Authorization:key=AAAAHea1TKw:APA91bEVgv1PDP8h70SzagB12RxkbEuT-5l7NL89rt0zFvXX3xgx2cdsNJ98yAvoXcMr235-3alJdmR1pTKrjFm9NB8AAmo76bPesNJXHFcf2-gpS-pv1yndQfF26qPgFO5lFLHKqLLO', 'Content-Type:application/json');
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
    $result = curl_exec($ch);
    if ($result === FALSE)
        die("CURL FAILED: " . curl_error($ch));
    curl_close($ch);
    return $result;
}

$query = "SELECT token FROM $table";
$result = mysqli_query($con, $query) or die("ERROR");
$tokens = array();
if (mysqli_num_rows($result) > 0):
    while ($row = mysqli_fetch_assoc($result)) {
        $tokens[] = $row['token'];
    }
endif;
mysqli_close($con);

$message = array(
    "message" => $subject,
    "body" => $myMessage,
);
$message_status = send_notification($tokens, $message);
echo $message_status;


